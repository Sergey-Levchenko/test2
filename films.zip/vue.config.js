module.exports = {
  "transpileDependencies": [
    "vuetify"
  ]
}